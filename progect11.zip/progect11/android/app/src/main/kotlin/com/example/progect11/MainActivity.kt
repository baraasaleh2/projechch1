package com.example.progect11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
