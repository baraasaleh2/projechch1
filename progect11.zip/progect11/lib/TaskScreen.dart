import 'package:flutter/material.dart';

class Task_Screen1 extends StatelessWidget {
  final padding = EdgeInsets.symmetric(horizontal: 20);
  bool checkBoxValue0 = false;
  bool checkBoxValue1 = false;
  bool checkBoxValue2 = false;

  get titleController => null;



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          title: Text("" , style: TextStyle(),),
          backgroundColor: Colors.black,
        ),
        drawer: Drawer(
            child: Container(
                color: Colors.grey,
                child: ListView(
                    children: [

                      DrawerHeader(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  colors: <Color> [Colors.grey, Colors.white10]
                              )
                          ),
                          child:Column(
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Baraa Saleh ',
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                  IconButton(icon: Icon(Icons.search), onPressed: () {  }, ),
                                  IconButton(icon: Icon(Icons.notifications), onPressed: () {  },),
                                  IconButton(icon: Icon(Icons.settings), onPressed: () {  },),
                                ],
                              )
                            ],
                          )

                      ),
                      buildMenuItem(
                          icon: Icon(Icons.today),
                          title: "Today",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon: Icon(Icons.inbox),
                          title: "Inbox",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon: Icon(Icons.hail),
                          title: "Welcome",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon: Icon(Icons.work),
                          title: "Work",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon:const Icon(Icons.home),
                          title: "Personal",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon:const Icon(Icons.shop),
                          title: "Shopping",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon:const Icon(Icons.list_alt_outlined),
                          title: "Wish List",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                      buildMenuItem(
                          icon:const Icon(Icons.cake),
                          title: "Birthday",
                          onClick: (){
                            selectItem(context, 0);
                          }
                      ),
                    ]
                )

            )
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(label: "", icon: Icon(Icons.check_box)),
          BottomNavigationBarItem(label: "", icon: Icon(Icons.calendar_today_outlined)),
          BottomNavigationBarItem(label: "", icon: Icon(Icons.settings)),
        ],),
           body: Column(
            children: [
    //add listview.builder
    Container(
      height: 250,
      child:ListView(
        children: [
          ListTile(
            title: Text("I Would like to state the code"),
            trailing: Checkbox(
              value: false,
              onChanged: null,
            ),
          ),
          ListTile(
            title: Text("Meating with Team!"),
            trailing: Checkbox(
              value: false,
              onChanged: null,
            ),
          ),
          ListTile(
            title: Text("go to the gym"),
            trailing: Checkbox(
              value: false,
              onChanged: null,
            ),
          ),
        ],
      ), ),

Container(
  padding: EdgeInsets.only(left: 50 ,top :250),

  child: FloatingActionButton(
    onPressed: (){
      showModalBottomSheet(context: context, builder: (context)=> Container(
        child: Column(
          children: const [
            Text("what do you want to do", style: TextStyle(color: Colors.grey,fontSize: 18,fontWeight: FontWeight.bold),)

          ],
        ),
      ),
      );
    },

      child:const Icon(Icons.add, color: Colors.black,),
),
)
  ],
),
      ),
    );
  }
}
buildMenuItem({required Icon icon, required String title, required Function onClick}){

  return ListTile(
    leading: icon,
    title: Text(title),
    onTap: (){
      onClick();
    },
  );
}

selectItem(BuildContext context, int index){
  switch(index){
    case 0: Navigator.push;


    break;
    case 1: Navigator.push;

    break;
    case 2:
      Navigator.push;
  }
}